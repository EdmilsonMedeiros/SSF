<?php
if ($_SERVER('REQUEST_METHOD' == 'POST')){
    
    include 'conexao.php';
    
}
?>