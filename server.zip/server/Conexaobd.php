<?php 
$host = "Localhost";
$user = "id5459026_edmilsonmedeiros";
$pass = "91687074a";
$db = "id5459026_sussemfila";

$connect = new mysqli($host,$user,$pass,$db);

if(!$connect){
    echo "Erro na conexao";
}else{ 
    
   }
?>