<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){
 	verificar();
}

function verificar()
{
    //SUPORTE SYSTEM
    $suporteVersion = "1.5";

    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];
	global $connect;
    	
		$result_user = $connect->query("SELECT * FROM `paciente` WHERE `cpf` ='$cpf'");
		$result_all  = $connect->query("SELECT * FROM `paciente` WHERE `cpf` ='$cpf' AND `senha` = '$senha'");
	
	$rowuser = mysqli_fetch_array($result_user);
	$rowall = mysqli_fetch_array($result_all);
	
	if($rowuser > 0){
          if($rowall > 0){
	$json['confirmado'] = "confirmado";
		$json['nome'] = $rowuser['nome'];
		$json['cpf'] = $rowuser['cpf'];
		$json['id'] = $rowuser['id'];
		$json['suporte'] = $suporteVersion;
		echo json_encode($json);
		
        }else{
      	    $json['error'] = " Senha Incorreta!";
      	    $json['suporte'] = $suporteVersion;
		echo json_encode($json);
        }}else{
	    $json['error'] = " Este cpf não consta no sistema";
	    $json['suporte'] = $suporteVersion;
		echo json_encode($json);
	}
}
//---------------------------

//---------------------------



// 	mysqli_close($connect);

?>