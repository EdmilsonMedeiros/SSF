<?php

// API access key from Google API's Console
define( 'API_ACCESS_KEY', 'AIzaSyBrW_KAa7bNQK2IplWZMl-3vbAO-cZ8Hw4' );


$registrationIds = array( 'dP7GwMN54No:APA91bGjcVmbchPV6yeBh8L5WfaHl2s_xbU59EDNXQyd6vYuLNyLz504mCZZYKiU4kROO7EGGRsNGw9EyTDVZigAffs2_DbDHgBnHPXxyke7fggjmXP5v7vU611AcFzrUqThd0K3nSNB' );

// prep the bundle
$msg = array
(
	'message' 	=> 'pode Usar data',
	'title'		=> 'Mensgem do PHP',
	'subtitle'	=> 'This is a subtitle. subtitle',
	'tickerText'	=> 'Ticker text here...Ticker text here...Ticker text here',
	'vibrate'	=> 1,
	'sound'		=> 1,
	'largeIcon'	=> 'large_icon',
	'johnson' => 'legal',
	"natan" => "meu filho",
	'smallIcon'	=> 'small_icon'
);
$notification = array(
	"sound"=> "simpleSound.wav",
    "badge"=> "10",
    "title"=> "PARA ROBSON",
    "icon"=> "myicon",
    "body"=> "Aqui vai um teste",
	
    "notification_id" => "1140",
    "notification_type" => 1,
    "notification_message" => "TEST MESSAGE",
    "notification_title" => "APP"
);
$fields = array
(
	'registration_ids' 	=> $registrationIds,
	'data'			=> $msg,
	'notification' => $notification
);
 
$headers = array
(
	'Authorization: key=' . API_ACCESS_KEY,
	'Content-Type: application/json'
);
 
$ch = curl_init();
curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
curl_setopt( $ch,CURLOPT_POST, true );
curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
$result = curl_exec($ch );
curl_close( $ch );

echo $result;