<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  refresh(); }


function refresh(){
    
	$id = $_POST["id"];

	global $connect;
    	
        $result = $connect->query("SELECT ha.hr_atendimento AS horario, h.descricao AS hospital, a.id, ha.data_atendimento AS dt_consulta, e.descricao, a.fk_especialidade AS especialidade, a.status, p.img_profile FROM agendamento a
        INNER JOIN horarios_atendimento ha ON a.fk_info_agendamento = ha.id
        INNER JOIN especialidade e ON e.cod_especialidade = a.fk_especialidade
        INNER JOIN paciente p ON a.fk_paciente = p.id
        INNER JOIN hospital h ON ha.fk_hospital = h.id
        WHERE a.status = 'Em andamento' AND fk_paciente = '$id'
        ORDER BY a.dt_criacao DESC");
        
        $linhas = $connect->query("SELECT COUNT(*) agendamento");
	
	$row = $linhas->num_rows;

	if($row > 0){

    $json = array();
	
	while($ros = $result->fetch_assoc()){
	    $linha = array();	
	    $linha['id'] = $ros["id"];
        $linha['data'] = date('d-m-Y', strtotime($ros["dt_consulta"])); 
        $linha['horario'] = $ros["horario"];
	    $linha['especialidade'] = $ros["especialidade"];
	    $linha['descricao'] = $ros["descricao"];
	    $linha['status'] = $ros["status"];
		$linha['hospital'] = $ros["hospital"];
	    $json[] = $linha;
	}
		 echo json_encode($json);

	}else{
	    $json['error'] = "Inativo no momento";
		echo json_encode($json);
	    
	}
}
	mysqli_close($connect);
?>	