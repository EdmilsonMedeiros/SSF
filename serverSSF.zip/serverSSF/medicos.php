<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  buscarmedico(); }


function buscarmedico(){
	global $connect;
	$hospital = $_POST["hospital"];
    	
        $result = $connect->query("SELECT * FROM medico WHERE fk_hospital = '$hospital'");
        $linhas = $connect->query("SELECT COUNT(*) FROM medico WHERE fk_hospital = '$hospital'");
	
	$row = $linhas->num_rows;
 $json = array();
	if($row > 0){

	while($ros = $result->fetch_assoc()){
	    $linha = array();	
		$linha['id'] = $ros["id"];
		$linha['nome'] = $ros["nome"];
	    $json[] = $linha;
	}
		 echo json_encode($json);

	}else{
		$json['error'] = "Inativo no momento";
		echo json_encode($json);
	}

}
	mysqli_close($connect);
?>