<?php

$host = "localhost";
$usuario = "id5459026_edmilsonmedeiros";
$senha = "91687074a";
$bd = "id5459026_sussemfila";

$mysqli = new mysqli($host, $usuario, $senha, $bd);

if($mysqli->connect_errno)
  echo "Falha na conexão: (".$mysqli->connect_errno.") ".$mysqli->connect_error;

?>