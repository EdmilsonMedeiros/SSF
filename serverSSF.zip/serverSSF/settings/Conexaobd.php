<?php
$connect = mysqli_connect('localhost','id5459026_edmilsonmedeiros','91687074a','id5459026_sussemfila');

if(isset($connect)){
    
}else {
    mysqli_error();
}
?>