<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  delete(); }


function delete(){
    
	$id = $_POST["id"];
    $idp = "";
	global $connect;
    	
        $query1 = $connect->query("SELECT `fk_info_agendamento` FROM `agendamento` WHERE `agendamento`.`id` = '$id'");
        $dados = mysqli_fetch_assoc($query1);
        $idp = $dados['fk_info_agendamento'];
    	$query2 = "UPDATE `horarios_atendimento` SET `situacao` = 'ABERTO' WHERE `horarios_atendimento`.`id` = '$idp'";
        mysqli_query($connect, $query2);
        $query = "UPDATE `agendamento` SET `status` = 'Cancelado' WHERE `agendamento`.`id` = '$id'";
        
        if(mysqli_query($connect, $query)){
            $json['confirmado'] = "confirmado";
	        echo json_encode($json);
        }
   
	mysqli_close($connect);
}
?>	