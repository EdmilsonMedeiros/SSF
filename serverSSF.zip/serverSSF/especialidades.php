<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';


	global $connect;
    	
        $result = $connect->query("SELECT * FROM especialidade");
        $linhas = $connect->query("SELECT COUNT(*) FROM especialidade");
	
	$row = $linhas->num_rows;

	if($row > 0){

    $json = array();
	
	while($ros = $result->fetch_assoc()){
	    $linha = array();	
		$linha['id'] = $ros["cod_especialidade"];
		$linha['descricao'] = $ros["descricao"];
	    $json[] = $linha;
	}
		 echo json_encode($json);

	}else{
	    $json['error'] = "Inativo no momento";
		echo json_encode($json);
	    
	}


	mysqli_close($connect);

?>