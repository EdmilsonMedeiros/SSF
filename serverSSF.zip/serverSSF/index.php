<?php
    session_start();
    $connect = mysqli_connect("localhost", "id5459026_edmilsonmedeiros", "91687074a", "id5459026_sussemfila");
    if (isset($_POST['email'])){
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        md5(base64_encode($senha));
        
$login = "SELECT * ";
$login .= "FROM secretario ";
$login .= "WHERE email = '{$email}' and senha = '{$senha}'";
        $acesso = mysqli_query($connect, $login);
        if (!$acesso){
            die ("Falha na Consulta");
        }
        $informacao = mysqli_fetch_assoc($acesso);
        if(empty($informacao)){
            $mensagem = "<style>.pErro{color: red;}</style><p class='pErro'>Dados incorretos</p>";
            
        }else{
            $_SESSION["pode_passar"] = $informacao['id'];
            header("location:https://sussemfila.000webhostapp.com/_admin/");
        }     
    }
?>

<!DOCTYPE HTML>
<html>

<head>
	<title>Administrador</title>
	<!-- Meta-Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Admin sus sem fila, sussemfila, administrador sussemfila">
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta-Tags -->
	<!-- Stylesheets -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<!--// Stylesheets -->
	<!--fonts-->
	<!-- Title -->
	<link href="//fonts.googleapis.com/css?family=Eczar:400,500,600,700,800" rel="stylesheet">
	<!-- Body -->
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
	<!--//fonts-->
</head>

<body>
	<!--<h1>Administrador </h1>--><br>
	<div class="w3ls-login">
		<!-- form starts here -->
		
		                
		
		
		<form action="" method="post">
			<div class="w3ls-ribbon">
				<div class="ribbon-wrapper">
					<div class="glow">&nbsp;</div>
					<div class="ribbon-front">
						<h2>Entre com sua conta</h2>
					</div>
				</div>
			</div>
			<div class="agile-field-txt">
				<label>
					Usuário :</label>
				<input type="text" value="" name="email" placeholder="Email " required="" />
			</div>
			<div class="agile-field-txt">
				<label>
					Senha :</label>
				<input type="password" name="senha" placeholder="Senha " required="" id="myInput" />
				<div class="agile_label">
					<input id="check3" name="check3" type="checkbox" value="show password" onclick="myFunction()">
					<label class="check" for="check3">Mostrar Senha</label>
					<?php
                if(isset($mensagem)){
                ?>
                <p><?php echo $mensagem;?></p>
                <?php
                    }
                ?>
				</div>
			</div>
			<!-- script for show password -->
			<script>
				function myFunction() {
					var x = document.getElementById("myInput");
					if (x.type === "password") {
						x.type = "text";
					} else {
						x.type = "password";
					}
				}
			</script>
			<!-- //script for show password -->
			<div class="w3ls-login  w3l-sub">
				<input type="submit" value="Login">
			</div>
			<p class="agile-bot">
				<a href="#">Registrar</a>
			</p>
		</form>
	</div>
	<!-- //form ends here -->
	<!--copyright-->
	<div class="copy-wthree">
		<p>© 2018 GeekStorm . All Rights Reserved | Design by
			<a href="" target="_blank">GeekStorm</a>
		</p>
	</div>
	<!--//copyright-->
</body>

</html>