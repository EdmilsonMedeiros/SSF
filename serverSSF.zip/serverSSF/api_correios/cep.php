<?php
header('Content-Type: application/json; charset=utf-8');  

  class BuscaCep{
      public $cep = "";
      
      
      function buscar($cep){
          $url = "https://viacep.com.br/ws/$cep/json/";
          $json = file_get_contents($url);
          return json_decode($json, true);
      }
      
  }

?>

