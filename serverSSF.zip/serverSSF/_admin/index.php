<?php
session_start();
    $connect = mysqli_connect("localhost", "id5459026_edmilsonmedeiros", "91687074a", "id5459026_sussemfila");

    if(isset($_SESSION["pode_passar"])){
        
    }else{
        header("location:https://sussemfila.000webhostapp.com");
    }
    
?>

<!-- saved from url=(0053)https://sussemfila.000webhostapp.com/_admin/index.php -->
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        	<meta charset="UTF 8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="https://sussemfila.000webhostapp.com/css/bootstrap.min.css">
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<style type="text/css">
	    .page-header{
	        text-align:center;
	        color: #0404B4;
	    }
	    .header{
	        text-align:center;
	    }
	    .imsAg{
	        height:10em;
	        
	    }
	    <meta name="RATING" content="RTA-5042-1996-1400-1577-RTA">
	   
	/*--------------------------------------------------------------*/
	</style>
	<script type="text/javascript">
	$('#myModal2').on('shown.bs.modal', function () {
    $('#myInput2').focus()
    })
	    function reLoad(){
	        return location.reload();
	    }
	    
	    
	    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').focus()
        })
	    
	</script>
    </head>
<body>

	
	    
	<div class="container ">
	    <div class="row">
	            <div class="col-xs-12">
		            <h2 class="header">Painel Hospital X</h2>
		        </div>
	    </div>
    </div>
    <div class="container menu">
	    <div class="row">
	            <div class="col-xs-12">
	                <div class="nav-bar">
	                    <nav>
	                        
	                        <ol class="breadcrumb">
                                <li><a href="https://sussemfila.000webhostapp.com/_admin/">Consultas Agendadas</a></li>
                                <li><a href="https://sussemfila.000webhostapp.com/_admin/_historico">Histórico</a></li>
                                <li><a href="https://sussemfila.000webhostapp.com/_admin/">Agendar</a></li>
                                <li><a href="https://sussemfila.000webhostapp.com/_admin/">Cadastrar Paciente</a></li>
                                <li><a href="https://sussemfila.000webhostapp.com/_admin/">Alterar Dados</a></li>
                                <li><a href="logout.php" class="sair">Sair</a></li>
                                <!--desativado<li class="active">Cadastrar Paciente</li>-->
                            </ol>
	                        
	                    </nav>
	                    
	                </div>
	               
		            <h3></h3>
		        </div>
	    </div>
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col">
                <center>
                <img class="imsAg" src="https://sussemfila.000webhostapp.com/images/botaoconsultaagendadas.png">
                <br>
                <!----------------------------------Boas Vindas----------------------------------------------------->
                <?php
                    $bv = mysqli_query($connect,"SELECT nome FROM secretario WHERE id='{$_SESSION['pode_passar']}'");
                    while($nome=mysqli_fetch_assoc($bv)){
                        echo "<style>.bv2{color:red;}</style><b class='bv2'>Seja bem vindo(a) ".$nome["nome"]."<b>";
                    }
                    
                ?>
                               
                <!-------------------------------------------------------------------------------------------------->
                </b></b></center><b class="bv"><b>
                <h1 class="page-header"></h1>
            </b></b></div><b class="bv"><b>
        </b></b></div><b class="bv"><b>
    </b></b></div><b class="bv"><b>
    
    
    <div class="container ">
        
	    <div class="row">
	            <div class="col-xs-12">
		            <div class="table-responsive">
                    <!-- Default panel contents -->
                    
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                    <tr>
                        <th>Numero</th>
                        <th>Nome</th>
                        <th>Data</th>
                        <th>Ficha</th>
                        <th>Ação</th>
                    </tr>
                        </thead>
                    
                <tbody>
                    <?php
                    $bv = mysqli_query($connect,"SELECT agendamento.id, agendamento.dt_consulta, paciente.nome, hospital.descricao, medico.especialidade, especialidade.descricao as descricao_e  FROM agendamento INNER JOIN paciente ON paciente.id = agendamento.paciente INNER JOIN hospital ON agendamento.hospital = hospital.id INNER JOIN medico ON agendamento.medico=medico.id  INNER JOIN especialidade ON agendamento.especialidade = especialidade.cod_especialidade WHERE agendamento.status='Em andamento'");
                    while($nome=mysqli_fetch_assoc($bv)){
                    ?>
                
                    <tr>
                    <td><?php echo $nome['id']?></td>
                    <th><?php echo $nome['nome']?></th>
                    <td><?php echo $nome['dt_consulta']?></td>
                    <td><a data-toggle="modal" data-target=".bs-example-modal-lg<?php echo $nome['id']?>" href="">Abrir</a></td>
                    <style>.ob{margin-right:3em;}</style>
                    <td><a class="ob" data-toggle="modal" data-target=".modal-my<?php echo $nome['id']?>" href="">Fazer observações</a><input type="submit" name="finalizar" value="Finalizar" class="btn btn-primary"/></td>
                    
                    
                    
        <!-- /.modal -->
                    <!-- Large modal -->
                    <div class="modal fade bs-example-modal-lg<?php echo $nome['id']?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" id="myModal">
                      <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                          <div class="modal-header bg-primary" >
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                               <h2 class="modal-title"><center>Ficha número <?php echo $id = $nome['id'];?></center></h2>
                              </div> 
                               
                                <div class="modal-body">
                                    <center><h3><?php echo "<b>Hospital: ".$nome['descricao']."</b><br><br>"?></h3>
                                        <!--<p><?//php echo "Hospital: ".$nome['endereco']."<br><br>"?></p>-->
                                        <p>Rua das Bruxarias, 666, Natal/RN</p>
                                        <p>(84)3232-3232</p>
                                    </center><br><br>
                                <h4>    
                                <?php echo "<b>Nome:</b> ".$nome['nome']."<br><br>"?>
                                    
                                <?php echo "<b>Agendado para: </b>".$nome['dt_consulta']."<br><br>"?>        
                                
                                <?php echo "<b>Especialidade:</b> ".$nome['descricao_e']."<br><br>"?>
                                </h4>
                                
                                <h3 class="modal-title">Observações</h3>
                                <h5 class"recuo">
                        - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nec velit imperdiet, eleifend tortor porta, faucibus lectus. Nunc nunc dolor, imperdiet ut vehicula sit amet, aliquet at massa. Sed vestibulum lorem non lorem sollicitudin rutrum. Aliquam et nibh at nisl tempus rutrum. In sem sem, sollicitudin bibendum quam a, semper mattis ex. Donec vulputate sodales sem, dictum elementum tellus luctus vitae. Curabitur id mi venenatis, aliquam nisl at, finibus elit. Morbi ullamcorper eros nibh, sit amet varius lectus cursus id. Aenean vel lectus elementum urna mattis laoreet.
                                </h5><br><br><br>
                                
                                
                                </div>
                                
                    
                          <div class="bg-primary modal-footer bts"><style>.bts{padding:3em;}</style>
                            <button type="button" class="btn btn-default">IMPRIMIR</button>
                            
                            <button type="button" class="btn btn-danger">BAIXAR</button>

                            <!--<form name="finalizale" method="post">-->
                                
                            <!--</form>-->
                            <style>
                            </style>

<?php
/*
    $f = $_POST['finalizar'];
    if(isset($f)){
    $connect = mysqli_connect("localhost", "id5459026_edmilsonmedeiros", "91687074a","id5459026_sussemfila");
    $sql = mysqli_query($connect, "UPDATE agendamento SET status = '{$_POST['finalizar']}' WHERE agendamento.id = '{$id}'");
    // header("Location:https://sussemfila.000webhostapp.com/_admin/");
    }
    */
?>                         
                          </div>
                        </div>
                      </div>
                    </div>
<!-----------------------fimModal-->
<div class=" modal fade modal-my<?php echo $nome['id']?>" tabindex="-1" role="dialog" id="myModal2">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <!--<h4 class="modal-title">Observações</h4>-->
      </div>
      <div class="modal-body">
        <form action="">
        <div class="form-group">
        <label for="email">Observações</label>
        <textarea class="form-control" rows="5" id="comment"></textarea>
        </div>
        </form>
  
      </div>
      <div class="modal-footer bg-danger">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn  btn-primary">Save changes</button>
        </div>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php
     }
?>
<!------------------------------------>
                    
                </tbody>
                    </table>   
                    </div>
		        </div>
	    </div>
    </div>
    
    
    
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://sussemfila.000webhostapp.com/js/bootstrap.min.js"></script>
    <script src="https://sussemfila.000webhostapp.com/js/npm.js"></script>
	<div style="text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;display:block !important;"><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website_sussemfila&amp;utm_content=footer_img"><img src="./index.php_files/footer-powered-by-000webhost-white2.png" alt="www.000webhost.com"></a></div>
	
</b></b><br><br></body></html>