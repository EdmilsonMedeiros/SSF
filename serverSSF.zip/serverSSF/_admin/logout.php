<?php
    session_start();
if(isset($_SESSION['pode_passar'])){
    session_destroy();
    header("Location:http://sussemfila.000webhostapp.com");
}
?>