<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  buscarhospital(); }


function buscarhospital(){
	global $connect;
	$hospitalesp = $_POST["especialidade"];
    	
        $result = $connect->query("SELECT h.id, h.descricao FROM atendimentohospital ah 
                                   INNER JOIN hospital h ON ah.fk_hospital = h.id
                                   WHERE ah.fk_especialidade = '$hospitalesp'");
        $linhas = $connect->query("SELECT COUNT(*) FROM atendimentohospital ah 
                                   INNER JOIN hospital h ON ah.fk_hospital = h.id
                                   WHERE ah.fk_especialidade = '$hospitalesp'");
	
	$row = $linhas->num_rows;
 $json = array();
	if($row > 0){

	while($ros = $result->fetch_assoc()){
	    $linha = array();	
		$linha['id'] = $ros["id"];
		$linha['descricao'] = $ros["descricao"];
	    $json[] = $linha;
	}
		 echo json_encode($json);

	}else{
		$json['error'] = "Inativo no momento";
		echo json_encode($json);
	}

}
	mysqli_close($connect);
?>