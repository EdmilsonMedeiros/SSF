<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  atendimento(); }


function atendimento(){
	global $connect;
	$medico = $_POST["medico"];
    	
        $result = $connect->query("SELECT * FROM `horarios_atendimento` WHERE `fk_medico` = '$medico' AND `situacao` = 'ABERTO'");
        $linhas = $connect->query("SELECT COUNT(*) FROM `horarios_atendimento` WHERE `fk_medico` = '$medico'");
	
	$row = $linhas->num_rows;
 $json = array();
	if($row > 0){

	while($ros = $result->fetch_assoc()){
	    $linha = array();	
		$linha['id'] = $ros["id"];
		$linha['Data'] = $ros["data_atendimento"];
		$linha['Time'] = $ros["hr_atendimento"];
	    $json[] = $linha;
	}
		 echo json_encode($json);

	}else{
		$json['error'] = "Inativo no momento";
		echo json_encode($json);
	}

}
	mysqli_close($connect);
?>