<?php
    header('Content-Type: application/json');
    require 'settings/Conexaobd.php';
    
    global $connect;
?>