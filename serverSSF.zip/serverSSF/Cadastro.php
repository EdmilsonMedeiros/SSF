<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';
include 'api_correios/cep.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  createCadastro(); }


function createCadastro(){
   			 global $connect;
    		 $buscar = new BuscaCep();
    
    		 $nome = $_POST['nome'];
			 $cep = $_POST['endereco'];
			 $numerocpf = $_POST['numerocpf'];
			 $numerosus = $_POST['numerosus'];
		     $email = $_POST['email'];
			 $senha = $_POST['senha'];
			 //Trabalhar o Token
			 $toc = $_POST['token'];
	
			 $result = $buscar->buscar($cep);
	
			 $endereco = $result['logradouro'];
			 $cidade = $result['localidade'];
	

		$query = "SELECT * FROM `paciente` WHERE `cpf` ='$numerocpf'";
		$search = mysqli_fetch_array(mysqli_query($connect, $query));
	
	if($search > 0){}
	else{
	    
	    
	$query = "INSERT INTO `paciente`(`nome`, `email`, `senha`, `endereco`, `cidade`, `cpf`, `numerosus`, `token`)
	VALUE ('$nome','$email','$senha','$endereco','$cidade','$numerocpf','$numerosus','$toc')";
	
	    if(mysqli_query($connect, $query)){
	              // API access key from Google API's Console
define( 'API_ACCESS_KEY', 'AIzaSyBrW_KAa7bNQK2IplWZMl-3vbAO-cZ8Hw4' );


$registrationIds = array( $toc );

// prep the bundle
$notification = array(
	"sound"=> "simpleSound.wav",
    "badge"=> "6",
    "title"=> "SEJA BEM VINDO!",
    "icon"=> "myicon",
    "body"=> "Seu cadastro foi realizado com sucesso.",
	
    "notification_id" => "1140",
    "notification_type" => 1,
    "notification_message" => "TEST MESSAGE",
    "notification_title" => "APP"
);
$fields = array
(
	'registration_ids' 	=> $registrationIds,
	'data'			=> $msg,
	'notification' => $notification
);
 
$headers = array
(
	'Authorization: key=' . API_ACCESS_KEY,
	'Content-Type: application/json'
);
 
$ch = curl_init();
curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
curl_setopt( $ch,CURLOPT_POST, true );
curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
$result = curl_exec($ch );
curl_close( $ch );

echo $result;
          
      
	    
	    }
	    
	}
	
	mysqli_close($connect);
};


?>