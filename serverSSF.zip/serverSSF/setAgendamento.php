<?php
header('Content-Type: application/json');
require 'settings/Conexaobd.php';

if($_SERVER["REQUEST_METHOD"]=="POST"){  createAgendamento(); }

function createAgendamento(){
    global $connect;    
    $especialidade = $_POST['especialidade'];
    $hospital = $_POST['hospital'];
    $medico = $_POST['medico'];
    $atendimento = $_POST['atendimento'];
    $paciente = $_POST['paciente'];
    $dataAtual =  date('y/m/d');
    
    $query = "INSERT INTO `agendamento`(`dt_criacao`, `fk_info_agendamento`, `fk_paciente`, `fk_medico`, `fk_hospital`, `fk_especialidade`, `status`, `presente`) 
            VALUES ('$dataAtual','$atendimento','$paciente','$medico','$hospital','$especialidade','Em andamento','Andamento')";
    $query2 = "UPDATE `horarios_atendimento` SET `situacao` = 'FECHADO' WHERE `horarios_atendimento`.`id` = '$atendimento'";
    mysqli_query($connect, $query2);
            
            if(mysqli_query($connect, $query)){
                $json['confirmado'] = "confirmado";
	            echo json_encode($json);
            }
   
	mysqli_close($connect);
  

}
?>